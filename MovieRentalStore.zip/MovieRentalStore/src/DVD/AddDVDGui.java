/**
 * @author Liyabona Saki & Emihle Menzo
 * @version 1.0
 * Date:
 * 
 */

package DVD;

import movierentalstore.Menu;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class AddDVDGui extends JFrame implements ActionListener {

    private JPanel panelNorth;
    private JPanel panelCenter, panelRB1, panelRB2;
    private JPanel panelSouth;
    
    private JLabel lblEventLogo;
    private JLabel lblHeading;
    
    //DVD Number
    private JLabel lblPadding1, lblPadding2, lblPadding3;
    private JLabel lblDVDNumber;
    private JTextField txtDvdNumber;
    private JLabel lblDvdErr;
    
    //Title
    private JLabel lblTitle;
    private JTextField txtTitle;
    private JLabel lblTitleErr;
    
    //Categoty
    private JLabel lblCategory;
    private JTextField txtCategory;
    private JLabel lblCatergoryErr;
    
    //Price
    private JLabel lblPrice;
    private JTextField txtPrice;
    private JLabel lblPriceErr;
    
    private JLabel lblProgramme;
    private JComboBox cboProgramme;
    private JLabel lblBlank4;
    
    private JLabel lblRent;
    private JRadioButton radRentTrue;
    private JRadioButton radRentFalse;
    private JLabel lblBlank5;
    
    private JLabel lblRelease;
    private JRadioButton radReleaseTrue;
    private JRadioButton radReleaseFalse;
    private JLabel lblBlank6;
    
    private JLabel lblPadding4, lblPadding5, lblPadding6;
    private ButtonGroup releaseGroup;
    private ButtonGroup rentGroup;
    
    private JButton btnSave, btnClear, btnBack;
    private Font ft1, ft2, ft3;
        
    public AddDVDGui() {
        super("MasterLAB DVDs");
        panelNorth = new JPanel();
        panelCenter = new JPanel();
        panelRB1 = new JPanel();
        panelRB2 = new JPanel();
        panelSouth = new JPanel();
        
        lblEventLogo = new JLabel(new ImageIcon("MovieIcon.png"));
        lblHeading = new JLabel("Add a new DVD");

        lblPadding1 = new JLabel();
        lblPadding2 = new JLabel();
        lblPadding3 = new JLabel();
        
        lblDVDNumber = new JLabel("DVD Number: ");
        txtDvdNumber = new JTextField();
        lblDvdErr = new JLabel("*DVD Number is required");
        lblDvdErr.setVisible(false);
        
        
        lblTitle = new JLabel("Title: ");
        txtTitle = new JTextField();
        lblTitleErr = new JLabel("*Title is required");
        lblTitleErr.setVisible(false);
        
        //category
        lblCategory = new JLabel("Category: ");
        txtCategory = new JTextField();
        lblCatergoryErr = new JLabel("*Category is required");
        lblCatergoryErr.setVisible(false);
        
        //phone
        lblPrice= new JLabel("Price: ");
        txtPrice= new JTextField();
        lblPriceErr= new JLabel("*Price is required");
        lblPriceErr.setVisible(false);
        
        //programme
//        lblProgramme = new JLabel("Programme: ");
//        cboProgramme = new JComboBox();
//        cboProgramme.addItem("Applications Development");
//        cboProgramme.addItem("Communication Networks");
//        cboProgramme.addItem("Multimedia Technology");
        
        lblBlank4 = new JLabel(""); //Space
        
        //TODO
        lblRent = new JLabel("Avaliable for rent: ");
        radRentTrue = new JRadioButton("True");
        radRentFalse = new JRadioButton("False");
        
        lblBlank5 = new JLabel("");//Space
        
        lblRelease = new JLabel("New release : ");
        radReleaseTrue = new JRadioButton("True");
        radReleaseFalse = new JRadioButton("False");
        
        lblBlank6 = new JLabel(""); //Space
        
        lblPadding4 = new JLabel();
        lblPadding5 = new JLabel();
        lblPadding6 = new JLabel();
        
        //TODO
        releaseGroup = new ButtonGroup();
        rentGroup = new ButtonGroup();
        
        btnSave = new JButton("Save");
        btnClear = new JButton("Clear");
        btnBack = new JButton("Back");
        
        ft1 = new Font("Arial", Font.BOLD, 32);
        ft2 = new Font("Arial", Font.PLAIN, 20);
        ft3 = new Font("Arial", Font.PLAIN, 22);
    }
    
    public void setGUI() {
        panelNorth.setLayout(new FlowLayout());
        panelCenter.setLayout(new GridLayout(9, 1));
        panelRB1.setLayout(new GridLayout(1, 2));
        panelRB2.setLayout(new GridLayout(1, 2));
        panelSouth.setLayout(new GridLayout(1, 3));
        
        panelNorth.add(lblEventLogo);
        panelNorth.add(lblHeading);
        lblHeading.setFont(ft1);
        lblHeading.setForeground(Color.yellow);
        panelNorth.setBackground(new Color(0, 106, 255));
        
        lblPadding1.setFont(ft1);
        panelCenter.add(lblPadding1);
        lblPadding2.setFont(ft1);
        panelCenter.add(lblPadding2);
        lblPadding3.setFont(ft1);
        panelCenter.add(lblPadding3);
        
        lblDVDNumber.setFont(ft2);
        lblDvdErr.setFont(ft2);
        lblDvdErr.setForeground(Color.red);
        lblDVDNumber.setHorizontalAlignment(JLabel.RIGHT);
        txtDvdNumber.setFont(ft2);
        panelCenter.add(lblDVDNumber);
        panelCenter.add(txtDvdNumber);
        panelCenter.add(lblDvdErr);
        
        lblTitle.setFont(ft2);
        lblTitleErr.setFont(ft2);
        lblTitleErr.setForeground(Color.red);
        lblTitle.setHorizontalAlignment(JLabel.RIGHT);
        txtTitle.setFont(ft2);
        panelCenter.add(lblTitle);
        panelCenter.add(txtTitle);
        panelCenter.add(lblTitleErr);
        
        lblCategory.setFont(ft2);
        lblCatergoryErr.setFont(ft2);
        lblCatergoryErr.setForeground(Color.red);
        lblCategory.setHorizontalAlignment(JLabel.RIGHT);
        txtCategory.setFont(ft2);
        panelCenter.add(lblCategory);
        panelCenter.add(txtCategory);
        panelCenter.add(lblCatergoryErr);
        
        //price
        lblPrice.setFont(ft2);
        lblPriceErr.setFont(ft2);
        lblPriceErr.setForeground(Color.red);
        lblCategory.setHorizontalAlignment(JLabel.RIGHT);
        txtPrice.setFont(ft2);
        panelCenter.add(lblPrice);
        panelCenter.add(txtPrice);
        panelCenter.add(lblPriceErr);
        
        //programme
//        lblProgramme.setFont(ft2);
//        lblProgramme.setHorizontalAlignment(JLabel.RIGHT);
//        cboProgramme.setFont(ft2);
//        panelCenter.add(lblProgramme);
//        panelCenter.add(cboProgramme);
        panelCenter.add(lblBlank4);
        panelCenter.setBackground(new Color(36, 145, 255));
        
        lblRelease.setFont(ft2);
        lblRelease.setHorizontalAlignment(JLabel.RIGHT);
        radReleaseTrue.setFont(ft2);
        radReleaseTrue.setHorizontalAlignment(JRadioButton.CENTER);
        radReleaseTrue.setBackground(new Color(36, 145, 255));
        radReleaseFalse.setFont(ft2);
        radReleaseFalse.setHorizontalAlignment(JRadioButton.LEFT);
        radReleaseFalse.setBackground(new Color(36, 145, 255));
        radReleaseTrue.setSelected(true);
        
        releaseGroup.add(radReleaseTrue);
        releaseGroup.add(radReleaseFalse);
        
        panelCenter.add(lblRelease);      
        panelRB1.add(radReleaseTrue);
        panelRB1.add(radReleaseFalse);
        panelCenter.add(panelRB1);
        panelCenter.add(lblBlank5);
        
        
        //TODO
        lblRent.setFont(ft2);
        lblRent.setHorizontalAlignment(JLabel.RIGHT);
        radRentTrue.setFont(ft2);
        radRentTrue.setHorizontalAlignment(JRadioButton.CENTER);
        radRentTrue.setBackground(new Color(36, 145, 255));
        radRentFalse.setFont(ft2);
        radRentFalse.setHorizontalAlignment(JRadioButton.LEFT);
        radRentFalse.setBackground(new Color(36, 145, 255));
        radRentTrue.setSelected(true);
        
        rentGroup.add(radRentTrue);
        rentGroup.add(radRentFalse);
        
        panelCenter.add(lblRent);
        panelRB2.add(radRentTrue);
        panelRB2.add(radRentFalse);
        panelCenter.add(panelRB2);
        panelCenter.add(lblBlank6);
        panelRB1.setBackground(new Color(36, 145, 255));
        panelRB2.setBackground(new Color(36, 145, 255));
        panelCenter.setBackground(new Color(36, 145, 255));
        
        lblPadding4.setFont(ft1);
        panelCenter.add(lblPadding4);
        lblPadding5.setFont(ft1);
        panelCenter.add(lblPadding5);
        lblPadding6.setFont(ft1);
        panelCenter.add(lblPadding6);
        
        btnSave.setFont(ft3);
        btnClear.setFont(ft3);
        btnBack.setFont(ft3);
        panelSouth.add(btnSave);
        panelSouth.add(btnClear);
        panelSouth.add(btnBack);
        
        this.add(panelNorth, BorderLayout.NORTH);
        this.add(panelCenter, BorderLayout.CENTER);
        this.add(panelSouth, BorderLayout.SOUTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        btnSave.addActionListener(this);
        btnClear.addActionListener(this);
        btnBack.addActionListener(this);
        
        this.setSize(700, 700);
        this.pack();
        this.setVisible(true);
    }
    
    private boolean isInputValid() {
        boolean valid = true;
        if (txtCategory.getText().equals("")) {
            lblCatergoryErr.setVisible(true);
            txtCategory.requestFocus();
            valid = false;
        }
        else 
            lblCatergoryErr.setVisible(false);
        
        if (txtPrice.getText().equals("")) {
            lblPriceErr.setVisible(true);
            txtPrice.requestFocus();
            valid = false;
        }
        else 
            lblPriceErr.setVisible(false);
        
        if (txtTitle.getText().equals("")) {
            lblTitleErr.setVisible(true);
            txtTitle.requestFocus();
            valid = false;
        }
        else 
            lblTitleErr.setVisible(false);
        
        if (txtDvdNumber.getText().equals("")) {
            lblDvdErr.setVisible(true);
            txtDvdNumber.requestFocus();
            valid = false;
        }
        else 
            lblDvdErr.setVisible(false);
        
        return valid;
    }
    
    private void clearForm() {
        txtDvdNumber.setText("");
            lblDvdErr.setVisible(false);
            txtTitle.setText("");
            lblTitleErr.setVisible(false);
            txtCategory.setText("");
            lblCatergoryErr.setVisible(false);
            txtPrice.setText("");
            lblPriceErr.setVisible(false);
//            cboProgramme.setSelectedIndex(0);
            radReleaseTrue.setSelected(true);
            radRentTrue.setSelected(true);
            
//            radDeviceYes.setSelected(true);
            txtDvdNumber.requestFocus();
    }
    
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Save")) {

            if (isInputValid()) {
            
                    try {
                             
                        int DVDNo = Integer.parseInt(txtDvdNumber.getText());
                        String title = txtTitle.getText();
                        String category = txtCategory.getText();
                        String price = txtPrice.getText();
                        String newRelease = radReleaseTrue.isSelected()?"True":"False";
                        String availableForRent = radRentTrue.isSelected()?"True":"False";
                        
                        Class.forName("org.apache.derby.jdbc.ClientDriver");
                        try {
                            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/ADPFinalProject","root","root");
                            PreparedStatement prp;
                            
                            String insertData = "INSERT into DVDS (DVD_NO,DVD_TITLE,DVD_CATEGORY,DVD_PRICE,NEW_RELEASE,AVAILABLE) values (?,?,?,?,?,?)";
                            prp = con.prepareStatement(insertData);
                            
                            prp.setInt(1, DVDNo);
                            prp.setString(2, title);
                            prp.setString(3, category);
                            prp.setString(4,price);
                            prp.setString(5, newRelease);
                            prp.setString(6, availableForRent);
                            
                            prp.execute();
                            JOptionPane.showMessageDialog(null,"Data Saved");
                            
                        } catch (SQLException ex) {
                            ex.getSQLState();
                        }
                        

                clearForm();

                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(AddDVDGui.class.getName()).log(Level.SEVERE, null, ex);
                    }
                
            }
        }
        else if (e.getActionCommand().equals("Clear")) {
            clearForm();
        }   
        else if (e.getActionCommand().equals("Back")) {
            Menu mn = new Menu();
            mn.setVisible(rootPaneCheckingEnabled);
            this.dispose();
        }
        
    }
        
}

