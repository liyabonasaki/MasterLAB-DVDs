
package movierentalstore;

import javax.swing.JFrame;

/**
 *
 * @author Liyabona Saki & Emihle Menzo
 */
public class MovieRentalStore {

    
    public static void main(String[] args) {
       
        
      Menu m = new Menu();          // Integration on progress
      m.setVisible(true);
      
      
        ClientApp client = new ClientApp();
     
        client.communicate();
        client.closeClient();
    
    }
    
}
