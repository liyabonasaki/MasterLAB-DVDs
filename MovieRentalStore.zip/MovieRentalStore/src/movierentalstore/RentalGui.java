package movierentalstore;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Liyabona Saki & Emihle Menzo
 */
public class RentalGui  extends JFrame implements ActionListener{

  Connection con;
  Statement st;
  ResultSet rs;
  
  PreparedStatement pst;
   /* public DefaultTableModel tableModelRentals = new DefaultTableModel();
    private TableRowSorter<DefaultTableModel> tableRowSorterRental = new TableRowSorter<>(tableModelRentals);
    */
    DefaultTableModel tableModelRentals;
    JTable rentTable;
    private JScrollPane rentScrollPane;
    
    JButton btnReloadRent;
    JButton btnReturn;
    JButton btnHome;
    
    public RentalGui(){
        super("Rentals");
        
        setLayout(new GridLayout(1, 1, 5, 10));
        
        JPanel tPanel = new JPanel();
        
        tPanel.setLayout(null);
        tPanel.setBorder(BorderFactory.createTitledBorder("Store Rentals"));
        tPanel.setBounds(50, 20, 760, 300);
        
        tableModelRentals = new DefaultTableModel();
        rentTable = new JTable(tableModelRentals);
        btnReloadRent = new JButton("Refresh");
        btnReturn = new JButton("Return DVD");
        btnHome = new JButton("Home");

        /*
        (Rental_No, DateRented, DateReturned,"
                        + " Cust_No, DVD_No, PenaltyCostPerDay)
        */
        tableModelRentals.addColumn("Rental #");
        tableModelRentals.addColumn("Date Rented");
        tableModelRentals.addColumn("Date Retruned");
        tableModelRentals.addColumn("Customer #");
        tableModelRentals.addColumn("DVD Number");
        tableModelRentals.addColumn("Penalty Cost/day");
        
        rentScrollPane = new JScrollPane(rentTable);
        
        tPanel.add(rentScrollPane);
        tPanel.add(btnReloadRent); 
        tPanel.add(btnReturn);
        tPanel.add(btnHome);
        
        add(tPanel);
        
        btnReloadRent.setBounds(100, 200, 90, 20);
        btnReturn.setBounds(230, 200, 110, 20);
        btnHome.setBounds(380, 200, 90, 20);
        rentScrollPane.setBounds(40, 40, 500, 140);
        
        
        btnReloadRent.addActionListener(this);
        btnReturn.addActionListener(this);
        btnHome.addActionListener(this);
        
   /*     rentTable = new JTable(tableModelRentals);
        rentTable.setAutoCreateRowSorter(true);
        rentTable.setRowSorter(tableRowSorterRental);
        tableModelRentals = new SortableTableModel();
     //   rentScrollPane = new JScrollPane(rentTable);
     //   rentScrollPane.setBounds(40, 40, 500, 140);
       
        tableModelRentals= new DefaultTableModel(); 
        tableModelRentals.addColumn("DASD");
        
        tableModelRentals.addColumn("Rental #");
        tableModelRentals.addColumn("Date Rented");
        tableModelRentals.addColumn("Customer #");
        tableModelRentals.addColumn("DVD Number"); */
        
        
       // tPanel.add(rentScrollPane);
      //  add(tPanel);
        
        
        
    }
    public void DisplayRentalRec(JTable DefualtTableModel){
        try {
            try {
                Class.forName("org.apache.derby.jdbc.ClientDriver");
            } catch (ClassNotFoundException ex) {
                ex.getStackTrace();
            }
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/ADPFinalProject","root","root");
            st = con.createStatement();
            
            String query = "Select *from Rentals";
            rs = st.executeQuery(query);
            
            DefualtTableModel.setModel(DbUtils.resultSetToTableModel(rs));
            
        } catch (SQLException ex) {
            ex.getStackTrace();
        }
    }
   
    
    @Override
    public void actionPerformed(ActionEvent ae) {
       
        if(ae.getSource() == btnReloadRent){
            DisplayRentalRec(rentTable);
            
        }
        
        if(ae.getSource() == btnHome){
        ClientApp client = new ClientApp();
        this.dispose();
        
        client.setSize(1200, 600);
        client.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        client.setLocationRelativeTo(null);
        client.setResizable(false);
        client.setVisible(true);
        
        }
        
    }
    
}
