
package movierentalstore;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import net.proteanit.sql.DbUtils;

import movierentalserver.*;


/**
 *
 * @author Liyabona Saki & Emihle Menzo
 */
public class ClientApp extends JFrame implements ActionListener, KeyListener {

    Socket server;

    JMenu file = new JMenu("File");
    JMenuItem crtTables, loadTable;

    JLabel lblID = new JLabel("ID");
    JLabel lblName = new JLabel("Name");
    JLabel lblSurname = new JLabel("Surname");
    JLabel lblPhone = new JLabel("Phone");
    JLabel lblCredit = new JLabel("Credit");
    JLabel lblCanRent = new JLabel("Can Rent");
    JLabel lblDelete = new JLabel("Delete");
    JLabel lblDeleteDvd = new JLabel("Delete");

    JTextField txtID = new JTextField();
    JTextField txtName = new JTextField();
    JTextField txtSurname = new JTextField();
    JTextField txtPhone = new JTextField();
    JTextField txtCredit = new JTextField();

    JTextField txtSearch = new JTextField("");

//    JTextField txtCanRent = new JTextField();
    JCheckBox chkRent = new JCheckBox();
    JCheckBox chkDelete = new JCheckBox();
    JCheckBox chkDeleteDvd = new JCheckBox();

    JButton btnAdd = new JButton("Add");
    JButton btnUpdate = new JButton("Update");
    JButton btnDelete = new JButton("Delete");

    JButton btnCreateTables = new JButton("+ Tables");
    JButton btnLoadTables = new JButton("Load Tables");
    JButton btnViewDb = new JButton("Refresh");

    JButton btnHire = new JButton("Hire");
    //  JButton btnSearch = new JButton("Search");
    JButton btnRented = new JButton("Rentals");

    public SortableTableModel tableModelCustomers = new SortableTableModel();
    private TableRowSorter<SortableTableModel> tableRowSorterCust = new TableRowSorter<>(tableModelCustomers);
    private JTable customerTable;
    private JScrollPane custScrollPane;

    public SortableTableModel tableModelMovies = new SortableTableModel();
    private TableRowSorter<SortableTableModel> tableRowSorterDvd = new TableRowSorter<>(tableModelMovies);
    private JTable movieTable;
    private JScrollPane movieScrollPane;

    /**
     * * Movie Rental Side **
     */
    JLabel lblDvdID = new JLabel("DvD #");
    JLabel lblDvdTitle = new JLabel("Title");
    JLabel lblCategory = new JLabel("Category");
    JLabel lblRelease = new JLabel("Release");
    JLabel lblAvailable = new JLabel("Available");

    /*   JLabel lblAdd = new JLabel("New");
    JLabel lblUpdate = new JLabel("Update");
    JLabel lblDelete = new JLabel("Delete"); */
    JTextField txtDvdID = new JTextField();
    JTextField txtDvdTitle = new JTextField();

    private String[] category = {"Horror", "Sci-Fi", "Drama", "Romance", "Comedy", "Action", "Cartoon"};
    private JComboBox cat = new JComboBox(category);

    private String[] years = {"2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018",};
    private JComboBox yearReleased = new JComboBox(years);

    private String[] available = {"Yes", "No"};
    private JComboBox avail = new JComboBox(available);

    /*    JCheckBox chkAdd = new JCheckBox();
    JCheckBox chkUpdate = new JCheckBox();
    JCheckBox chkDelete = new JCheckBox();  */
    JButton btnAddDvd = new JButton("Add");
    JButton btnUpdateDvd = new JButton("Update");
    JButton btnDeleteDvd = new JButton("Delete");

    public ClientApp() {

        super("MasterLAB DVDs");

        setLayout(new GridLayout(1, 1, 5, 10));

        JPanel fPanel = new JPanel();
        JPanel custPanel = new JPanel();
        JPanel moviePanel = new JPanel();

        fPanel.setLayout(null);
        fPanel.setBorder(BorderFactory.createTitledBorder("Store Details"));
        fPanel.setBounds(50, 20, 760, 300);

        custPanel.setLayout(null);
        custPanel.setBackground(Color.lightGray);
        custPanel.setBorder(BorderFactory.createTitledBorder("Customer Details"));
        // custPanel.setSize(300, 400);
        custPanel.setBounds(20, 220, 550, 300);

        moviePanel.setLayout(null);
        moviePanel.setBackground(Color.lightGray);
        moviePanel.setBorder(BorderFactory.createTitledBorder("DVD Details"));
        moviePanel.setBounds(610, 220, 550, 300);

        //******************** JMenu ******************
        crtTables = new JMenuItem("Create Tables");
        crtTables.addActionListener(this);
        file.add(crtTables);

        loadTable = new JMenuItem("load Tables");
        loadTable.addActionListener(this);
        file.add(loadTable);

        //******************** JMenu ****************** 
        lblID.setBounds(25, 70, 100, 25);
        lblID.setFont(new Font("Times Roman", Font.PLAIN, 17));
        txtID.setBounds(80, 70, 150, 25);

        lblName.setBounds(25, 120, 100, 25);
        lblName.setFont(new Font("Times Roman", Font.PLAIN, 17));
        txtName.setBounds(80, 120, 150, 25);

        lblSurname.setBounds(290, 120, 100, 25);
        lblSurname.setFont(new Font("Times Roman", Font.PLAIN, 17));
        txtSurname.setBounds(370, 120, 150, 25);

        lblPhone.setBounds(25, 170, 100, 25);
        lblPhone.setFont(new Font("Times Roman", Font.PLAIN, 17));
        txtPhone.setBounds(80, 170, 150, 25);

        lblCredit.setBounds(310, 170, 100, 25);
        lblCredit.setFont(new Font("Times Roman", Font.PLAIN, 17));
        txtCredit.setBounds(370, 170, 150, 25);

        lblCanRent.setBounds(370, 70, 100, 25);
        lblCanRent.setFont(new Font("Times Roman", Font.PLAIN, 17));
        chkRent.setBounds(335, 72, 20, 20);

        lblDelete.setBounds(370, 30, 100, 25);
        lblDelete.setFont(new Font("Times Roman", Font.PLAIN, 17));
        chkDelete.setBounds(335, 32, 20, 20);

        lblDeleteDvd.setBounds(370, 58, 100, 25);
        lblDeleteDvd.setFont(new Font("Times Roman", Font.PLAIN, 17));
        chkDeleteDvd.setBounds(335, 60, 20, 20);

        btnAdd.setBounds(80, 220, 100, 20);
        btnUpdate.setBounds(240, 220, 100, 20);
        btnDelete.setBounds(400, 220, 100, 20);

        btnCreateTables.setBounds(40, 192, 100, 20);
        btnLoadTables.setBounds(200, 192, 120, 20);
        btnViewDb.setBounds(360, 192, 120, 20);
        btnHire.setBounds(990, 192, 120, 20);
//        btnSearch.setBounds(740, 192, 90, 20);
        btnRented.setBounds(740, 192, 90, 20);
        txtSearch.setBounds(850, 192, 120, 20);

        /**
         * ******* For Movie Side *****
         */
        lblDvdID.setBounds(25, 70, 100, 25);
        lblDvdID.setFont(new Font("Times Roman", Font.PLAIN, 17));
        txtDvdID.setBounds(80, 70, 150, 25);

        lblDvdTitle.setBounds(25, 120, 100, 25);
        lblDvdTitle.setFont(new Font("Times Roman", Font.PLAIN, 17));
        txtDvdTitle.setBounds(80, 120, 150, 25);

        lblCategory.setBounds(290, 120, 100, 25);
        lblCategory.setFont(new Font("Times Roman", Font.PLAIN, 17));
        cat.setBounds(370, 120, 150, 25);

        lblRelease.setBounds(20, 170, 100, 25);
        lblRelease.setFont(new Font("Times Roman", Font.PLAIN, 17));
        yearReleased.setBounds(80, 170, 150, 25);

        lblAvailable.setBounds(290, 170, 100, 25);
        lblAvailable.setFont(new Font("Times Roman", Font.PLAIN, 17));
        avail.setBounds(370, 170, 150, 25);

//        lblAdd.setBounds(120, 50, 100, 25);
//        lblAdd.setFont(new Font("Times Roman", Font.PLAIN, 14));
//        lblUpdate.setBounds(190, 50, 100, 25);
//        lblUpdate.setFont(new Font("Times Roman", Font.PLAIN, 14));
//        lblDelete.setBounds(280, 50, 100, 25);
//        lblDelete.setFont(new Font("Times Roman", Font.PLAIN, 14));
        /*        chkAdd.setBounds(150, 50, 20, 20);
        chkUpdate.setBounds(240, 50, 20, 20);
        chkDelete.setBounds(325, 50, 20, 20); */
        btnAddDvd.setBounds(110, 220, 100, 20);
        btnUpdateDvd.setBounds(250, 220, 100, 20);
        btnDeleteDvd.setBounds(390, 220, 100, 20);
        btnDeleteDvd.setEnabled(false);

        //////////////
        tableModelCustomers = new SortableTableModel();
        customerTable = new JTable(tableModelCustomers);

//        customerTable.setRowSelectionAllowed(true);
//        movieTable.setRowSelectionAllowed(true);
//        customerTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
//        movieTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        tableModelCustomers.addColumn("Customer #");
        tableModelCustomers.addColumn("Name");
        tableModelCustomers.addColumn("Surname");
        tableModelCustomers.addColumn("Phone");
        tableModelCustomers.addColumn("Credit");
        tableModelCustomers.addColumn("Can Rent");

        /////////////////////////////////
        tableModelMovies = new SortableTableModel();
        movieTable = new JTable(tableModelMovies);

        tableModelMovies.addColumn("DvD #");
        tableModelMovies.addColumn("Title");
        tableModelMovies.addColumn("Category");
        tableModelMovies.addColumn("New Release");
        tableModelMovies.addColumn("Available");

        /**
         * to add Default Rows to Table *
         */
       
        //AutoRowSorter
        customerTable.setAutoCreateRowSorter(true);
        customerTable.setRowSorter(tableRowSorterCust);
        //customerTable.setEnabled(false);

        movieTable.setAutoCreateRowSorter(true);
        movieTable.setRowSorter(tableRowSorterDvd);
        //movieTable.setEnabled(false);

        custScrollPane = new JScrollPane(customerTable);
        custScrollPane.setBounds(25, 40, 450, 140);

        movieScrollPane = new JScrollPane(movieTable);
        movieScrollPane.setBounds(660, 40, 450, 140);

        fPanel.add(btnCreateTables);
        fPanel.add(btnLoadTables);
        fPanel.add(custScrollPane);
        fPanel.add(movieScrollPane);
        fPanel.add(btnViewDb);
        fPanel.add(btnHire);
//        fPanel.add(btnSearch);
        fPanel.add(btnRented);
        fPanel.add(txtSearch);

        custPanel.add(lblID);
        custPanel.add(txtID);
        custPanel.add(lblName);
        custPanel.add(txtName);
        custPanel.add(lblSurname);
        custPanel.add(txtSurname);
        custPanel.add(lblPhone);
        custPanel.add(txtPhone);
        custPanel.add(lblCredit);
        custPanel.add(txtCredit);
        custPanel.add(lblCanRent);
        custPanel.add(lblDelete);
        custPanel.add(chkRent);
        custPanel.add(chkDelete);
        custPanel.add(btnAdd);
        custPanel.add(btnUpdate);
        btnDelete.setEnabled(false);
        custPanel.add(btnDelete);

        moviePanel.add(lblDvdID);
        moviePanel.add(txtDvdID);  ////////////////////
        moviePanel.add(lblDvdTitle);
        moviePanel.add(txtDvdTitle);  //////////////////// 
        moviePanel.add(lblCategory);
        moviePanel.add(cat);  ////////////////////
        moviePanel.add(lblRelease);
        moviePanel.add(yearReleased);  ////////////////////
        moviePanel.add(lblAvailable);
        moviePanel.add(avail);  ////////////////////

        /*   txtDvdID.setEditable(false);
        txtDvdTitle.setEditable(false);
        cat.setEditable(false);
        yearReleased.setEditable(false);
        avail.setEditable(false);
        btnAddDvd.setEnabled(false);
        btnUpdateDvd.setEnabled(false);
        btnDeleteDvd.setEnabled(false);  */
//        moviePanel.add(chkAdd);
//        moviePanel.add(lblAdd);
//        moviePanel.add(lblUpdate);
//        moviePanel.add(chkUpdate);
        moviePanel.add(chkDeleteDvd);
        moviePanel.add(lblDeleteDvd);
//       moviePanel.add(lblDelete);

        moviePanel.add(btnAddDvd);
        moviePanel.add(btnUpdateDvd);
        moviePanel.add(btnDeleteDvd);

        fPanel.add(custPanel);
        fPanel.add(moviePanel);
        //add(file);
        add(fPanel);

        btnAdd.addActionListener(this);
        btnUpdate.addActionListener(this);
        btnDelete.addActionListener(this);
        chkRent.addActionListener(this);
        chkDelete.addActionListener(this);
        chkDeleteDvd.addActionListener(this);

        btnCreateTables.addActionListener(this);
        btnLoadTables.addActionListener(this);
        btnViewDb.addActionListener(this);
        btnHire.addActionListener(this);
        txtSearch.addKeyListener(this);
//        btnSearch.addActionListener(this);
        btnRented.addActionListener(this);

//        chkAdd.addActionListener(this);
//        chkUpdate.addActionListener(this);
//        chkDelete.addActionListener(this);
        btnAddDvd.addActionListener(this);
        btnUpdateDvd.addActionListener(this);
        btnDeleteDvd.addActionListener(this);

        cat.addActionListener(this);
        yearReleased.addActionListener(this);
        avail.addActionListener(this);

        try {
            server = new Socket("127.0.0.1", 12345);
        } catch (IOException ex) {
            System.err.println("Cannot Connect");
        }
    }

    ObjectOutputStream out;
    ObjectInputStream in;

    String responce;

    public void communicate() {

        try {
            //     DisplayCustTableRec(customerTable);
            //              
            //      DisplayDvdTableRec(movieTable);

            out = new ObjectOutputStream(server.getOutputStream());
            out.flush();

            in = new ObjectInputStream(server.getInputStream());

            responce = " ";

            while (!responce.equalsIgnoreCase("terminate")) {

                responce = (String) in.readObject();

                System.out.println("Server said: " + responce);
                JOptionPane.showMessageDialog(this, responce);

            } // end while

        } //end try
        catch (IOException ex) {

            //    Logger.getLogger(ClientApp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {

            //    Logger.getLogger(ClientApp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception end) {

            System.out.println("Program terminated...");
        }
    }

    public void closeClient() {
        try {
            out.close();
            in.close();
            server.close();
        } catch (IOException ex) {
            System.out.println("Something went Wrong");
        }
    }
    Connection con;
    Statement st;
    ResultSet rs;

    PreparedStatement pst;

    public void DisplayCustTableRec(JTable SortableTableModel) {

        try {
            try {
                Class.forName("org.apache.derby.jdbc.ClientDriver");
            } catch (ClassNotFoundException ex) {
                ex.getStackTrace();
            }
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/ADPFinalProject","root","root");
            st = con.createStatement();
            String query = "SELECT * FROM ROOT.CUSTOMERS ORDER BY CUST_NAME ASC";
            rs = st.executeQuery(query);

            SortableTableModel.setModel(DbUtils.resultSetToTableModel(rs));
            //tableData.setModel(tableModelCustomers);

        } catch (SQLException ex) {
            Logger.getLogger(ClientApp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void DisplayDvdTableRec(JTable SortableTableModel) {

        try {
            try {
                Class.forName("org.apache.derby.jdbc.ClientDriver");
            } catch (ClassNotFoundException ex) {
                ex.getStackTrace();
            }
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/ADPFinalProject","root","root");
            st = con.createStatement();

            String query = "SELECT * FROM ROOT.DVDS ORDER BY DVD_CATEGORY ASC";
            rs = st.executeQuery(query);

            SortableTableModel.setModel(DbUtils.resultSetToTableModel(rs));
            //tableData.setModel(tableModelCustomers);

        } catch (SQLException ex) {
            Logger.getLogger(ClientApp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void DisplayRentalRec(JTable DefualtTableModel) {
        try {
            try {
                Class.forName("org.apache.derby.jdbc.ClientDriver");
            } catch (ClassNotFoundException ex) {
                ex.getStackTrace();
            }
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/ADPFinalProject","root","root");
            st = con.createStatement();

            String query = "SELECT * FROM ROOT.RENTALS ORDER BY DATERENTED ASC";
            rs = st.executeQuery(query);

            DefualtTableModel.setModel(DbUtils.resultSetToTableModel(rs));

        } catch (SQLException ex) {
            Logger.getLogger(ClientApp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    Integer id;
    String name;
    String surname;
    String number;
    double credit;

    boolean canRent;

    public void updateCustomer() {

        id = Integer.parseInt(txtID.getText());
        name = txtName.getText();
        surname = txtSurname.getText();
        number = txtPhone.getText();
        credit = Double.parseDouble(txtCredit.getText());

        if (chkRent.isSelected()) {
            canRent = true;
        } else {
            canRent = false;
        }

        try {
            try {
                Class.forName("org.apache.derby.jdbc.ClientDriver");
            } catch (ClassNotFoundException ex) {
                ex.getStackTrace();
            }
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/ADPFinalProject","root","root");
            st = con.createStatement();

            pst = con.prepareStatement("Update Customers SET Cust_Name = ?, Cust_Surname = ?, Cust_Phone = ?, Cust_Credit = ?, Can_Rent = ? WHERE Cust_No = ?");

            pst.setString(1, name);
            pst.setString(2, surname);
            pst.setString(3, number);
            pst.setDouble(4, credit);
            pst.setBoolean(5, canRent);
            pst.setInt(6, id);

            pst.executeUpdate();
            pst.close();

        } catch (SQLException ex) {
            Logger.getLogger(ClientApp.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    Integer movieId;
    String movieTitle, ctgy;
    boolean yRel, avlb = false;

    String mCat;

    public void updateMovie() {

        movieId = Integer.parseInt(txtDvdID.getText());
        movieTitle = txtDvdTitle.getText();

        ctgy = (String) cat.getSelectedItem();
        // int ct = Integer.parseInt(ctgy);
        int ct = cat.getSelectedIndex() + 1;

        int y = yearReleased.getSelectedIndex();
        int x = avail.getSelectedIndex();

        if (y == 11) {
            yRel = true;
        }

        if (x == 0) {
            avlb = true;
        }

        // yRel = (Boolean) Boolean.parseBoolean(yearReleased.getSelectedItem().toString());
        //  avlb = (Boolean) Boolean.parseBoolean(avail.getSelectedItem().toString());  
        System.out.println(movieId + " " + movieTitle + " " + ct + " " + yRel + " " + avlb);
        DVD dvd;

        //int dvdNumber, String title, int category, boolean newRelease, boolean avail
        dvd = new DVD(movieId, movieTitle, ct, yRel, avlb);
        System.out.println(dvd.toString());

        try {
            try {
                Class.forName("org.apache.derby.jdbc.ClientDriver");
            } catch (ClassNotFoundException ex) {
                ex.getStackTrace();
            }
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/ADPFinalProject","root","root");
            st = con.createStatement();

            pst = con.prepareStatement("Update DVDs SET DVD_title = ?, DVD_Category = ?, New_Release = ?, Available = ? WHERE DVD_No = ?");

            pst.setString(1, movieTitle);
            pst.setString(2, ctgy);
            pst.setBoolean(3, yRel);
            pst.setBoolean(4, avlb);
            pst.setInt(5, movieId);

            pst.executeUpdate();
            pst.close();

        } catch (SQLException ex) {
            Logger.getLogger(ClientApp.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    ArrayList<Customer> custArray = new ArrayList();
    ArrayList<DVD> dvdArray = new ArrayList();
    ArrayList<Rental> rentalArraylist = new ArrayList();
    

    public ArrayList<Customer> getCustArray() {
        ArrayList<Customer>customerArraylist = new ArrayList<>();
        try
        {
            out.writeObject("getallcostomers");
            out.flush();
        customerArraylist =(ArrayList<Customer>)in.readObject();
        
        }
        catch(IOException ie)
        {
        System.out.println(ie.getMessage());
        
        }
        catch(ClassNotFoundException ce)
        {
        System.out.println(ce.getMessage());
        }
        
        return customerArraylist;
       
    }
    public void rent (Rental rental)
    {
    try{
    out.writeObject("rent");
    out.flush();
    out.writeObject(rental);
    out.flush();
    
    }
    catch(IOException ie)
            {
                System.out.println(ie.getMessage());
            }
    
    
    }

    public ArrayList<DVD> getDvd() {
        
        ArrayList<DVD>dvdArraylist = new ArrayList<>();
        try
        {
            out.writeObject("getalldvds");
            out.flush();
        dvdArraylist =(ArrayList<DVD>)in.readObject();
        
        }
        catch(IOException ie)
        {
        System.out.println(ie.getMessage());
        
        }
        catch(ClassNotFoundException ce)
        {
        System.out.println(ce.getMessage());
        }
        
        return dvdArraylist;
     
    }
    public ArrayList<Rental> getRentalArray() {
        
        ArrayList<Rental>rentalArraylist = new ArrayList<>();
        try
        {
            out.writeObject("getallrentals");
            out.flush();
        rentalArraylist =(ArrayList<Rental>)in.readObject();
        
        }
        catch(IOException ie)
        {
        System.out.println(ie.getMessage());
        
        }
        catch(ClassNotFoundException ce)
        {
        System.out.println(ce.getMessage());
        }
        
        return rentalArraylist;
    }
    public ArrayList<String> getRentalDates() {
        
        ArrayList<String>rentalDates = new ArrayList<>();
        try
        {
            out.writeObject("getrentaldate");
            out.flush();
        rentalDates =(ArrayList<String>)in.readObject();
        
        }
        catch(IOException ie)
        {
        System.out.println(ie.getMessage());
        
        }
        catch(ClassNotFoundException ce)
        {
        System.out.println(ce.getMessage());
        }
        
        return rentalDates;
    }

//    ServerApp sa;
    DefaultTableModel model;

    
    //Add DVD
    public void addingDvd() {
        model = (DefaultTableModel) movieTable.getModel();

        ArrayList<DVD> dvdList = new ArrayList();
        Object dvdRowData[] = new Object[6];
        model.setRowCount(0);
        // tableModelMovies.setRowCount(0);

        //int dvdNumber, String title, int category, boolean newRelease, boolean avai
        // tableModelMovies.addRow(new Object[]{dvdArray.get(i).getDvdNumber(), dvdArray.get(i).getTitle(), dvdArray.get(i).getCategory(), dvdArray.get(i).isNewRelease(), dvdArray.get(i).isAvailable()});
        for (int i = 0; i < dvdArray.size(); i++) {

            dvdRowData[0] = dvdArray.get(i).getDvdNumber();
            dvdRowData[1] = dvdArray.get(i).getTitle();
            dvdRowData[2] = dvdArray.get(i).getCategory();
            dvdRowData[3] = dvdArray.get(i).isNewRelease();
            dvdRowData[4] = dvdArray.get(i).isAvailable();

            model.insertRow(i, dvdRowData);
        }

    }

    public void addingCustomers() {
        ////////////
           tableModelCustomers = (SortableTableModel) customerTable.getModel();

        model = (DefaultTableModel) customerTable.getModel();

        ArrayList<Customer> list = new ArrayList();

        Object custRowData[] = new Object[6];
        model.setRowCount(0);

        for (int i = 0; i < custArray.size(); i++) {

            custRowData[0] = custArray.get(i).getCustNumber();
            custRowData[1] = custArray.get(i).getName();
            custRowData[2] = custArray.get(i).getSurname();
            custRowData[3] = custArray.get(i).getPhoneNum();
            custRowData[4] = custArray.get(i).getCredit();
            custRowData[5] = custArray.get(i).canRent();

            model.insertRow(i, custRowData);

        }

    }

    public void search(String movie) {

        try {
            boolean status = false;
            try {
                Class.forName("org.apache.derby.jdbc.ClientDriver");
            } catch (ClassNotFoundException ex) {
                ex.getStackTrace();
            }
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/ADPFinalProject","root","root");
            st = con.createStatement();

            String query = "Select * From DVDs Where DVD_title = '" + movie + "'";
            rs = st.executeQuery(query);

            while (rs.next()) {
                String title = rs.getString("DVD_title");

                if (title.equals(movie)) {
                    status = true;
                    tableRowSorterDvd.setRowFilter(RowFilter.regexFilter(query));
                    JOptionPane.showMessageDialog(null, "User Found");
                } else {
                    status = false;
                }
            }

        } catch (SQLException ex) {
            System.out.println("Could not search");

            //   return status;
        }
    }

    public void hire() {
        int selectedCustRow = customerTable.getSelectedRow();
        int selectedDvdRow = movieTable.getSelectedRow();

        if (selectedCustRow < 0 || selectedDvdRow < 0) {

            JOptionPane.showMessageDialog(null, "Select atleast 1 Customer and Dvd to confirm Rental");
        }
        customerTable.setRowSelectionAllowed(true);
        movieTable.setRowSelectionAllowed(true);
        
        
        //TODO
        boolean available;    //String
        boolean canMakeRent;  //String

        available = (boolean) movieTable.getValueAt(selectedDvdRow, 4);
        canMakeRent = (boolean) customerTable.getValueAt(selectedCustRow, 5);

        if (movieTable.getValueAt(selectedDvdRow, 4).equals(true) && customerTable.getValueAt(selectedCustRow, 5).equals(true)) {

            ArrayList<Customer> custArray = new ArrayList();
            ArrayList<DVD> dvdArray = new ArrayList();
            ArrayList<Rental> rentalArray = new ArrayList();
            

            int counter = 1;
            for (int i = 0; i < counter; i++) {
                try {
                    Class.forName("org.apache.derby.jdbc.ClientDriver");
                    con = DriverManager.getConnection("jdbc:derby://localhost:1527/ADPFinalProject","root","root");
                    st = con.createStatement();

                    SimpleDateFormat df = new SimpleDateFormat("yyyy.MM.dd");
                    Calendar cal = Calendar.getInstance();
                    String mDate = df.format(cal);

                    int custNo = (Integer) customerTable.getValueAt(selectedCustRow, 5);
                    int dvdNo = (Integer) movieTable.getValueAt(selectedDvdRow, 4);
                    double penalty = 5.00;
                    i++;
                    // counter = counter + 1;

                    /*
               pst = con.prepareStatement("Update Customers SET Cust_Name = ?, Cust_Surname = ?, Cust_Phone = ?, Cust_Credit = ?, Can_Rent = ? WHERE Cust_No = ?");
                 
                     */
//              if(counter > 1){
//                  counter = (Integer.parseInt(surname))
//              } 
                    pst = con.prepareStatement("INSERT INTO Rentals(Rental_No, DateRented, DateReturned,"
                            + " Cust_No, DVD_No, PenaltyCostPerDay) VALUES ('" + i + "', '" + mDate + "', '" + mDate + "', '" + custNo + "', '" + dvdNo + "', '" + penalty + "')");
                    pst.executeUpdate();
                   // i++;
                    break;

                    //   out.writeObject("Rented");
                    //   out.flush();
                    /*
                prepStat = conn.prepareStatement("INSERT INTO Customers (Cust_No, Cust_Name, Cust_Surname, "
                        + "Cust_Phone, Cust_Credit, Can_Rent) VALUES (?,?,?,?,?,?)");
                     */
                } catch (SQLException ex) {
                    Logger.getLogger(ClientApp.class.getName()).log(Level.SEVERE, null, ex);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Customer number already exists. Try With a differet Customer Number");
                }
            }

            JOptionPane.showMessageDialog(null, "Rental Successfull");

            
        }
        if (customerTable.getValueAt(selectedCustRow, 5).equals(false)) {
            JOptionPane.showMessageDialog(null, "Customer cannot make Rental");

        }
        if (movieTable.getValueAt(selectedDvdRow, 4).equals(false)) {
            JOptionPane.showMessageDialog(null, "Movie cannot be Rented out");
        }

    }

    //Add Button
    @Override
    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == btnAdd) {

            try {

                id = Integer.parseInt(txtID.getText());
                name = txtName.getText();
                surname = txtSurname.getText();
                number = txtPhone.getText();
                credit = Double.parseDouble(txtCredit.getText());
                
                
                if (chkRent.isSelected()) {
                    canRent = true;
                } else {
                    canRent = false;
                }

                getCustArray().add(new Customer(id, name, surname, number, credit, canRent));
                
                //          tableModelCustomers = (SortableTableModel) customerTable.getModel();

        model = (DefaultTableModel) customerTable.getModel();

        ArrayList<Customer> list = new ArrayList();
        
        Object custRowData[] = new Object[6];
        model.setRowCount(0);
        
        for (int i = 0; i < getCustArray().size(); i++) {
            id = getCustArray().get(i).getCustNumber();
            name =  getCustArray().get(i).getName();
            surname = getCustArray().get(i).getSurname();
            number = getCustArray().get(i).getPhoneNum();
            credit = getCustArray().get(i).getCredit();
            canRent = getCustArray().get(i).canRent();
            
            custRowData[0] =   id;
            custRowData[1] = name; 
            custRowData[2] = surname;
            custRowData[3] = number;
            custRowData[4] = credit;
           custRowData[5] = canRent;

            model.insertRow(i, custRowData);

        }

                
                
                for (int i = 0; i < custArray.size(); i++) {
                    out.writeObject(custArray.get(i).toString());
                }

       
       

               // addingCustomers();

                txtID.setText("");
                txtName.setText("");
                txtSurname.setText("");
                txtPhone.setText("");
                txtCredit.setText("");
                chkRent.setSelected(false);

            } catch (IOException ex) {
                Logger.getLogger(ClientApp.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        if (ae.getSource() == btnUpdate) {

            updateCustomer();
            JOptionPane.showMessageDialog(null, "Customer record Updated Successfully");
            txtID.setText("");
            txtName.setText("");
            txtSurname.setText("");
            txtPhone.setText("");
            txtCredit.setText("");
        }

        if (ae.getSource() == btnDelete) {
            try {
                out.writeObject("Rmv" + txtID.getText());
                txtID.setText("");

            } catch (IOException ex) {
                Logger.getLogger(ClientApp.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        if (ae.getSource() == chkDelete) {

            if (chkDelete.isSelected()) {
                btnDelete.setEnabled(true);
                txtName.setEnabled(false);
                txtPhone.setEnabled(false);
                txtSurname.setEnabled(false);
                txtCredit.setEnabled(false);
            } else {
                btnDelete.setEnabled(false);
                txtName.setEnabled(true);
                txtPhone.setEnabled(true);
                txtSurname.setEnabled(true);
                txtCredit.setEnabled(true);
            }
        }

        if (ae.getSource() == chkDeleteDvd) {
            if (chkDeleteDvd.isSelected()) {

                btnDeleteDvd.setEnabled(true);
                txtDvdTitle.setEnabled(false);
                cat.setEnabled(false);
                avail.setEnabled(false);
                yearReleased.setEnabled(false);

            } else {
                btnDeleteDvd.setEnabled(false);
                txtDvdTitle.setEnabled(true);
                cat.setEnabled(true);
                avail.setEnabled(true);
                yearReleased.setEnabled(true);
            }

        }

        if (ae.getSource() == btnCreateTables) {
            try {
                out.writeObject("Create tables");


            } catch (IOException ex) {
                //  Logger.getLogger(ClientApp.class.getName()).log(Level.SEVERE, null, ex);
            } catch (NullPointerException npe) {
                JOptionPane.showMessageDialog(null, "Tables already created");
            }
        }

        if (ae.getSource() == btnLoadTables) {
            try {
                out.writeObject("Load tables");

            } catch (IOException ex) {
                ex.getStackTrace();
            }
        }

        if (ae.getSource() == btnViewDb) {

            DisplayCustTableRec(customerTable);
            DisplayDvdTableRec(movieTable);
            

        }

        if (ae.getSource() == btnUpdateDvd) {
            updateMovie();
            JOptionPane.showMessageDialog(null, "Movie Record has been Successfully Updated");
            txtDvdID.setText("");
            txtDvdTitle.setText("");
            cat.setSelectedIndex(0);
            yearReleased.setSelectedIndex(0);
            avail.setSelectedIndex(0);

        }

        if (ae.getSource() == btnDeleteDvd) {
            try {
                out.writeObject("Dlt" + txtDvdID.getText());

                txtDvdID.setText("");
                txtDvdTitle.setText("");
                cat.setSelectedIndex(0);
                yearReleased.setSelectedIndex(0);
                avail.setSelectedIndex(0);

            } catch (IOException ex) {
                Logger.getLogger(ClientApp.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        if (ae.getSource() == btnRented) {

            RentalGui rg = new RentalGui();

            this.dispose();
            rg.setVisible(true);
            rg.setSize(600, 400);
            rg.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            rg.setLocationRelativeTo(null);

        }

        if (ae.getSource() == btnHire) {

            hire();

        }

        
        //Add DVD
        if (ae.getSource() == btnAddDvd) {
            

            try {
                movieId = Integer.parseInt(txtDvdID.getText());
                movieTitle = txtDvdTitle.getText();

                ctgy = (String) cat.getSelectedItem();

                int ct = cat.getSelectedIndex() + 1;
                int y = yearReleased.getSelectedIndex();
                int x = avail.getSelectedIndex();

                if (y == 11) {
                    yRel = true;
                }

                if (x == 0) {
                    avlb = true;
                }
                dvdArray.add(new DVD(movieId, movieTitle, ct, yRel, avlb));

                

                for (int i = 0; i < dvdArray.size(); i++) {

                    out.writeObject(dvdArray.get(i).toString());
                }

                
                

                addingDvd();

                txtDvdID.setText("");
                txtDvdTitle.setText("");
                cat.setSelectedIndex(0);
                yearReleased.setSelectedIndex(0);
                avail.setSelectedIndex(0);

               
            } catch (IOException ex) {
                ex.getStackTrace();
            }
        }
//        if (ae.getSource() == btnSearch){
//            try {
//                /*  String search = txtSearch.getText();
//                
//                search(search); */
//                out.writeObject("Read ser file");
//            } catch (IOException ex) {
//                Logger.getLogger(ClientApp.class.getName()).log(Level.SEVERE, null, ex);
//            }
//        } 
    }

    @Override
    public void keyTyped(KeyEvent ke) {
        model = (DefaultTableModel) movieTable.getModel();
        String search = txtSearch.getText().toUpperCase();
        TableRowSorter<DefaultTableModel> trs = new TableRowSorter(model);
        movieTable.setRowSorter(trs);
        trs.setRowFilter(RowFilter.regexFilter(search));
    }

    @Override
    public void keyPressed(KeyEvent ke) {

        model = (DefaultTableModel) movieTable.getModel();
        String search = txtSearch.getText().toUpperCase();
        TableRowSorter<DefaultTableModel> trs = new TableRowSorter(model);
        movieTable.setRowSorter(trs);
        trs.setRowFilter(RowFilter.regexFilter(search));

    }

    @Override
    public void keyReleased(KeyEvent ke) {

        model = (DefaultTableModel) movieTable.getModel();
        String search = txtSearch.getText().toLowerCase();
        TableRowSorter<DefaultTableModel> trs = new TableRowSorter(model);
        movieTable.setRowSorter(trs);
        trs.setRowFilter(RowFilter.regexFilter(search));
        
    }

}
