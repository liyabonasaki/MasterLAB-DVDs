package movierentalstore;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Liyabona Saki & Emihle Menzo
 */
public class SortableTableModel extends DefaultTableModel{
    
    public SortableTableModel(){
        super();
    }

    /**
     *
     * @param columnIndex
     * @return
     */
    @Override
    public Class<?> getColumnClass(int columnIndex){
        if(getColumnCount()<1 &&    getRowCount()<1){
            //table.setDefaultEditor(col_class, null);   
            return Object.class;
        }
        else{
            return getValueAt(0,columnIndex).getClass();
        }

    }
    
}