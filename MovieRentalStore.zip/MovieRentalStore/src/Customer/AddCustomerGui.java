/**
 * @author Liyabona Saki & Emihle Menzo
 * @version 1.0
 * Date:
 * 
 */

package Customer;

import movierentalstore.Menu;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class AddCustomerGui extends JFrame implements ActionListener {

    private JPanel panelNorth;
    private JPanel panelCenter, panelRB1, panelRB2;
    private JPanel panelSouth;
    
    private JLabel lblEventLogo;
    private JLabel lblHeading;
    
    private JLabel lblPadding1, lblPadding2, lblPadding3;
    private JLabel lblStudentNumber;
    private JTextField txtStudentNumber;
    private JLabel lblStudentErr;
    
    //First name
    private JLabel lblFirstName;
    private JTextField txtFirstName;
    private JLabel lblFirstNameErr;
    
    //last name
    private JLabel lblLastName;
    private JTextField txtLastName;
    private JLabel lblLastNameErr;
    
    //Phone
    private JLabel lblPhone;
    private JTextField txtPhone;
    private JLabel lblPhoneErr;
    
    //Credit
    private JLabel lblCredit;
    private JTextField txtCredit;
    private JLabel lblCreditErr;
    
    private JLabel lblBlank4;
    
    private JLabel lblDevice;
    private JRadioButton radDeviceYes;
    private JRadioButton radDeviceNo;
    private JLabel lblBlank5;
    private JLabel lblData;
    private JRadioButton radDataYes;
    private JRadioButton radDataNo;
    private JLabel lblBlank6;
    private JLabel lblPadding4, lblPadding5, lblPadding6;
    private ButtonGroup dataGroup;
//    private ButtonGroup deviceGroup;
    
    private JButton btnSave, btnClear, btnBack;
    private Font ft1, ft2, ft3;
        
    public AddCustomerGui() {
        super("MasterLAB DVDs");
        panelNorth = new JPanel();
        panelCenter = new JPanel();
        panelRB1 = new JPanel();
        panelRB2 = new JPanel();
        panelSouth = new JPanel();
        
        lblEventLogo = new JLabel(new ImageIcon("MovieIcon.png"));
        lblHeading = new JLabel("Add a Customer");

        lblPadding1 = new JLabel();
        lblPadding2 = new JLabel();
        lblPadding3 = new JLabel();
        
        lblStudentNumber = new JLabel("Customer Number: ");
        txtStudentNumber = new JTextField();
        lblStudentErr = new JLabel("*Customer Number is required");
        lblStudentErr.setVisible(false);
        
        
        lblFirstName = new JLabel("First Name: ");
        txtFirstName = new JTextField();
        lblFirstNameErr = new JLabel("*first name is required");
        lblFirstNameErr.setVisible(false);
        
        //lastname
        lblLastName = new JLabel("Last Name: ");
        txtLastName = new JTextField();
        lblLastNameErr = new JLabel("*last name is required");
        lblLastNameErr.setVisible(false);
        
        //phone
        lblPhone= new JLabel("Phone Number: ");
        txtPhone= new JTextField();
        lblPhoneErr= new JLabel("*Phone Number is required");
        lblPhoneErr.setVisible(false);
        
        //Credit
        lblCredit = new JLabel("Credit Amount: ");
        txtCredit = new JTextField();
        lblCreditErr= new JLabel("*Credit Amount is required");
        lblCreditErr.setVisible(false);
        
        lblBlank4 = new JLabel(""); //Space
        

        
        lblBlank5 = new JLabel("");//Space
        
        lblData = new JLabel("Can rent a movie? : ");
        radDataYes = new JRadioButton("True");
        radDataNo = new JRadioButton("False");
        
        lblBlank6 = new JLabel(""); //Space
        
        lblPadding4 = new JLabel();
        lblPadding5 = new JLabel();
        lblPadding6 = new JLabel();
        
        //TODO
        dataGroup = new ButtonGroup();
//        deviceGroup = new ButtonGroup();
        
        btnSave = new JButton("Save");
        btnClear = new JButton("Clear");
        btnBack = new JButton("Back");
        
        ft1 = new Font("Arial", Font.BOLD, 32);
        ft2 = new Font("Arial", Font.PLAIN, 20);
        ft3 = new Font("Arial", Font.PLAIN, 22);
    }
    
    public void setGUI() {
        panelNorth.setLayout(new FlowLayout());
        panelCenter.setLayout(new GridLayout(9, 1));
        panelRB1.setLayout(new GridLayout(1, 2));
        panelRB2.setLayout(new GridLayout(1, 2));
        panelSouth.setLayout(new GridLayout(1, 3));
        
        panelNorth.add(lblEventLogo);
        panelNorth.add(lblHeading);
        lblHeading.setFont(ft1);
        lblHeading.setForeground(Color.yellow);
        panelNorth.setBackground(new Color(0, 106, 255));
        
        lblPadding1.setFont(ft1);
        panelCenter.add(lblPadding1);
        lblPadding2.setFont(ft1);
        panelCenter.add(lblPadding2);
        lblPadding3.setFont(ft1);
        panelCenter.add(lblPadding3);
        
        lblStudentNumber.setFont(ft2);
        lblStudentErr.setFont(ft2);
        lblStudentErr.setForeground(Color.red);
        lblStudentNumber.setHorizontalAlignment(JLabel.RIGHT);
        txtStudentNumber.setFont(ft2);
        panelCenter.add(lblStudentNumber);
        panelCenter.add(txtStudentNumber);
        panelCenter.add(lblStudentErr);
        
        lblFirstName.setFont(ft2);
        lblFirstNameErr.setFont(ft2);
        lblFirstNameErr.setForeground(Color.red);
        lblFirstName.setHorizontalAlignment(JLabel.RIGHT);
        txtFirstName.setFont(ft2);
        panelCenter.add(lblFirstName);
        panelCenter.add(txtFirstName);
        panelCenter.add(lblFirstNameErr);
        
        lblLastName.setFont(ft2);
        lblLastNameErr.setFont(ft2);
        lblLastNameErr.setForeground(Color.red);
        lblLastName.setHorizontalAlignment(JLabel.RIGHT);
        txtLastName.setFont(ft2);
        panelCenter.add(lblLastName);
        panelCenter.add(txtLastName);
        panelCenter.add(lblLastNameErr);
        
        //phone
        lblPhone.setFont(ft2);
        lblPhoneErr.setFont(ft2);
        lblPhoneErr.setForeground(Color.red);
        lblLastName.setHorizontalAlignment(JLabel.RIGHT);
        txtPhone.setFont(ft2);
        panelCenter.add(lblPhone);
        panelCenter.add(txtPhone);
        panelCenter.add(lblPhoneErr);
        
        //Credit
        lblCredit.setFont(ft2);
        lblCreditErr.setFont(ft2);
        lblCreditErr.setForeground(Color.red);
        lblCredit.setHorizontalAlignment(JLabel.RIGHT);
        txtCredit.setFont(ft2);
        panelCenter.add(lblCredit);
        panelCenter.add(txtCredit);
        panelCenter.add(lblCreditErr);
        
        
        panelCenter.add(lblBlank4);
        panelCenter.setBackground(new Color(36, 145, 255));
        
        lblData.setFont(ft2);
        lblData.setHorizontalAlignment(JLabel.RIGHT);
        radDataYes.setFont(ft2);
        radDataYes.setHorizontalAlignment(JRadioButton.CENTER);
        radDataYes.setBackground(new Color(36, 145, 255));
        radDataNo.setFont(ft2);
        radDataNo.setHorizontalAlignment(JRadioButton.LEFT);
        radDataNo.setBackground(new Color(36, 145, 255));
        radDataYes.setSelected(true);
        
        dataGroup.add(radDataYes);
        dataGroup.add(radDataNo);
        
        panelCenter.add(lblData);      
        panelRB1.add(radDataYes);
        panelRB1.add(radDataNo);
        panelCenter.add(panelRB1);
        panelCenter.add(lblBlank5);
        
        
        //TODO
//        lblDevice.setFont(ft2);
//        lblDevice.setHorizontalAlignment(JLabel.RIGHT);
//        radDeviceYes.setFont(ft2);
//        radDeviceYes.setHorizontalAlignment(JRadioButton.CENTER);
//        radDeviceYes.setBackground(new Color(36, 145, 255));
//        radDeviceNo.setFont(ft2);
//        radDeviceNo.setHorizontalAlignment(JRadioButton.LEFT);
//        radDeviceNo.setBackground(new Color(36, 145, 255));
//        radDeviceYes.setSelected(true);
//        
////        deviceGroup.add(radDeviceYes);
////        deviceGroup.add(radDeviceNo);
//        
//        panelCenter.add(lblDevice);
//        panelRB2.add(radDeviceYes);
//        panelRB2.add(radDeviceNo);
//        panelCenter.add(panelRB2);
//        panelCenter.add(lblBlank6);
//        panelRB1.setBackground(new Color(36, 145, 255));
//        panelRB2.setBackground(new Color(36, 145, 255));
//        panelCenter.setBackground(new Color(36, 145, 255));
        
        lblPadding4.setFont(ft1);
        panelCenter.add(lblPadding4);
        lblPadding5.setFont(ft1);
        panelCenter.add(lblPadding5);
        lblPadding6.setFont(ft1);
        panelCenter.add(lblPadding6);
        
        btnSave.setFont(ft3);
        btnClear.setFont(ft3);
        btnBack.setFont(ft3);
        panelSouth.add(btnSave);
        panelSouth.add(btnClear);
        panelSouth.add(btnBack);
        
        this.add(panelNorth, BorderLayout.NORTH);
        this.add(panelCenter, BorderLayout.CENTER);
        this.add(panelSouth, BorderLayout.SOUTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        btnSave.addActionListener(this);
        btnClear.addActionListener(this);
        btnBack.addActionListener(this);
        
        this.setSize(700, 700);
        this.pack();
        this.setVisible(true);
    }
    
    private boolean isInputValid() {
        boolean valid = true;
        if (txtLastName.getText().equals("")) {
            lblLastNameErr.setVisible(true);
            txtLastName.requestFocus();
            valid = false;
        }
        else 
            lblLastNameErr.setVisible(false);
        
        if (txtPhone.getText().equals("")) {
            lblPhoneErr.setVisible(true);
            txtPhone.requestFocus();
            valid = false;
        }
        else 
            lblPhoneErr.setVisible(false);
        
        //
        if (txtCredit.getText().equals("")) {
            lblCreditErr.setVisible(true);
            txtCredit.requestFocus();
            valid = false;
        }
        else 
            lblCreditErr.setVisible(false);
        //
        
        if (txtFirstName.getText().equals("")) {
            lblFirstNameErr.setVisible(true);
            txtFirstName.requestFocus();
            valid = false;
        }
        else 
            lblFirstNameErr.setVisible(false);
        
        if (txtStudentNumber.getText().equals("")) {
            lblStudentErr.setVisible(true);
            txtStudentNumber.requestFocus();
            valid = false;
        }
        else 
            lblStudentErr.setVisible(false);
        
        return valid;
    }
    
    private void clearForm() {
        txtStudentNumber.setText("");
            lblStudentErr.setVisible(false);
            txtFirstName.setText("");
            lblFirstNameErr.setVisible(false);
            txtLastName.setText("");
            lblLastNameErr.setVisible(false);
            txtCredit.setText("");
            lblCreditErr.setVisible(false);
            txtPhone.setText("");
            lblPhoneErr.setVisible(false);
            radDataYes.setSelected(true);
            txtStudentNumber.requestFocus();
    }
    
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Save")) {
          
            if (isInputValid()) {
                   
                try {
                    int CustomerNo = Integer.parseInt(txtStudentNumber.getText());
                    String name = txtFirstName.getText();
                    String lastname = txtLastName.getText();
                    String phone = txtPhone.getText();
                    String credit = txtCredit.getText();
                    String canrent = radDataYes.isSelected()?"True":"False";
                    
                    
                    Class.forName("org.apache.derby.jdbc.ClientDriver");
                    try {
                        Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/ADPFinalProject","root","root");
                        PreparedStatement prp = null;
                        
                        String insertData = "insert into CUSTOMERS (CUST_NO,CUST_NAME,CUST_SURNAME,CUST_PHONE,CUST_CREDIT,CANRENT) values (?,?,?,?,?,?)";
                        prp = con.prepareStatement(insertData);
                        
                        prp.setInt(1, CustomerNo);
                        prp.setString(2, name);
                        prp.setString(3, lastname);
                        prp.setString(4,phone);
                        prp.setString(5, credit);
                        prp.setString(6, canrent);
                       
                        prp.execute();
                        JOptionPane.showMessageDialog(null,"Data Saved");
                        
                    } catch (SQLException ex) {
                        ex.getSQLState();
                    }
                    
                    

clearForm(); //Clear form
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(AddCustomerGui.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
        }
        else if (e.getActionCommand().equals("Clear")) {
            clearForm();
        }   
        else if (e.getActionCommand().equals("Back")) {
//            System.exit(0);
             Menu mn = new Menu();
             mn.setVisible(rootPaneCheckingEnabled);
             this.dispose();
        }
        
    }
        
}

