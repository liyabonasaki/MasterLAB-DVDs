package movierentalserver;

/**
 *
 * @author Liyabona Saki & Emihle Menzo
 */

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class ServerApp {
    
    public static ArrayList <Customer> list;
     
    //For Customer Class 
    private double credit;
    private int custNumber;
    private String firstName, surname, phoneNumber, creditStr;
    boolean can;
    private Scanner input;
    private String inputLine;
    private ObjectOutputStream outFile;
    
    Customer customerObj;
    
    private FileInputStream fis, mFis, rFis;
    private ObjectInputStream inFile, mInFile, rInFile;
    
    //For DVD Class
   private int dvdNumber, category;
    private String title, categoryStr, releaseStr, availableStr;
    private boolean release, available;
    
    DVD DvdObj;
    
    
    
    private int rentalNumber;
    private String dateRented;
    private String dateReturned;
   private double totalPenaltyCost;
    private double PENALTY_COST_PER_DAY;
    private int numDaysOverdue;
    Rental rent;
    
    ///
  
///
    
    ServerSocket listener;
    Socket client;
   
    public ServerApp(){
        
        try {
            listener = new ServerSocket(12345, 2);
            
        } catch (IOException ex) {
            Logger.getLogger(ServerApp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void listen(){
       
        try {
            System.out.println("Server is listening..");
            client = listener.accept();
            
            System.out.println("Processing Client requests...");
            
        } catch (IOException ex) {
            Logger.getLogger(ServerApp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    ObjectOutputStream out;
    ObjectInputStream in;
    
    Connection conn, dvdConn;
    Statement stmt;
    ResultSet rs;
    
    PreparedStatement prepStat, pStat;
    
    public void processClient(){
        
        try {
            in = new ObjectInputStream(client.getInputStream());
            //SHould manipulate DB here ... Call method from here
            out = new ObjectOutputStream(client.getOutputStream());
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/ADPFinalProject","root","root");
             stmt = conn.createStatement();
          
            System.out.println("Connected to Server...");
          
            out.flush();
         
            String msg = " ";
            int counter = 0;
            
           
            System.out.println("\n\n");
            while(!msg.equalsIgnoreCase("terminate")){
            
            counter ++;
                
            msg = (String)in.readObject();
            
            System.out.println("From Client: " + msg + "\n");
            
            if(msg.equalsIgnoreCase("Create tables")){
                createTables();
                System.out.println("Tables Created");
              //  JOptionPane.showMessageDialog(null, "Tables");
            } 
            
            if (msg.equalsIgnoreCase("Read ser file")){
                this.openFiles();
                this.readAndWrite();
                System.out.println("\n");
                
                this.openRentalFiles();
                this.readAndWriteRental();
                System.out.println("\n");
                
                this.openDvdFile();
                this.readAndWriteDvd();
                
                this.closeDvd();
                this.closeFiles(); 
            
            }
     
            //load tables
            if (msg.equalsIgnoreCase("Load tables")){
                
                this.openSerFiles();
                this.processCustSerFiles();
                this.processDvdSerFiles();
                this.processRentalsSerFile();
                this.closeSerFiles(); 
                
                out.writeObject("Tables loaded");
                out.flush();
             
            }
            
            if (msg.startsWith("D")){
                String nd = msg.substring(3);
                
            try{
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/ADPFinalProject" ,"root" ,"root");
            stmt = conn.createStatement();
            
            String query = "DELETE FROM DVDs WHERE DVD_No = " + nd;
            int a = stmt.executeUpdate(query);
            
            JOptionPane.showMessageDialog(null, "Movie Record removed from Database");
            
            } catch (SQLException ex) {
            Logger.getLogger(ServerApp.class.getName()).log(Level.SEVERE, null, ex);
        }
            }
          
            if (msg.startsWith("Rmv")){
                    String remove = msg.substring(3);
                
        
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/ADPFinalProject","root","root");
            stmt = conn.createStatement();
            
            String query = "DELETE FROM Customers WHERE Cust_No = " + remove;
            int a = stmt.executeUpdate(query);
            
            JOptionPane.showMessageDialog(null, "Customer Record removed from Database");
        
        } catch (SQLException ex) {
            ex.getStackTrace();
        }
          
    }
   
            
           }
           
            
        } catch (IOException ex) {
            System.out.println("Something went wrong");
        } catch (ClassNotFoundException ex) {
            System.out.println("Class not Found");
        }
        catch (SQLException ex) {
            System.out.println("SQL ERROR.....");
        }
        
    }
    
    public void createTables(){
        Statement stmt = null;
        Connection con = null;
        try {
            
            try {
                Class.forName("org.apache.derby.jdbc.ClientDriver");
            } catch (ClassNotFoundException ex) {
                ex.getStackTrace();
            }
             con = DriverManager.getConnection("jdbc:derby://localhost:1527/FinalAssignmentDB","root","root");
             stmt = con.createStatement();
             String query = "CREATE TABLE Customers("
                           + "Cust_no INT NOT NULL ,"
                           + "Cust_Name VARCHAR(255),"
                           + "Cust_Surname VARCHAR(255),"
                           + "Cust_Phone VARCHAR(255), "
                           + "Cust_Credit DOUBLE NOT NULL,,"
                           + "canRent VARCHAR(255), "
                           + "PRIMARY KEY (Cust_No))";
             
             stmt.execute(query);
            
     
               
             
               String query1 = "CREATE TABLE DVDs("
                           + "DVD_No INT NOT NULL ,"
                           + "DVD_title VARCHAR(255), Price DOUBLE NOT NULL, "
                           + "DVD_Category VARCHAR(255), "
                           + "New_Release VARCHAR(255), "
                           + "Available VARCHAR(255), "
                           + "PRIMARY KEY (DVD_No))";
             
             stmt.execute(query1);
               
         
             
                String query2 = "CREATE TABLE Rentals("
                           + "Rental_No INT NOT NULL ,"
                           + "DateRented VARCHAR(255),"
                           + "DateReturned VARCHAR(255), "
                           + "Cust_No INT NOT NULL,"
                           + "DVD_No INT NOT NULL,"
                           + "totalPenaltyCost DOUBLE,"
                           + "PenaltyCostPerDay DOUBLE NOT NULL,"
                           + "PRIMARY KEY (Rental_No))";
             
             stmt.execute(query2);

               out.writeObject("tables created");
               out.flush();
               this.stmt.close();
     
        } catch (SQLException ex) {
            System.out.println("Sorry something went wrong");
            ex.getStackTrace();
        } catch (IOException ex) {
           ex.getStackTrace();
        }
            
    }
    

    //open files
    
    public void openFiles()
    {
        try
        {
             //Reading Customers file and Ceating a new Customers.ser file  
            input = new Scanner(new File("D:\\Users\\Liyabona Saki\\Downloads\\Project2\\MovieRentalServer\\Customers.txt"));
            outFile = new ObjectOutputStream(new FileOutputStream("D:\\Users\\Liyabona Saki\\Downloads\\Project2\\MovieRentalServer\\Customers.ser"));
  
        }
        catch(FileNotFoundException fnf)
        {
            System.out.println("File not found...");
            System.exit(1);
        }
        catch(IOException ioe){
            System.out.println("Err opening output file");
        }
       
    }
    
     public void openRentalFiles()
    {
        try
        {
            input = new Scanner(new File("D:\\Users\\Liyabona Saki\\Downloads\\Project2\\MovieRentalServer\\Rentals.txt"));
            outFile = new ObjectOutputStream(new FileOutputStream("D:\\Users\\Liyabona Saki\\Downloads\\Project2\\MovieRentalServer\\Rental.ser"));
        }
        catch(FileNotFoundException fnf)
        {
            System.out.println("File not found...");
            System.exit(1);
        }
        catch(IOException ioe){
            System.out.println("Err opening output file");
        }
        
        
    }
  
    public void readAndWrite()
    {
        String[] arraySplit1 = new String[6];
        while(input.hasNext())
        {
            try
            {
                inputLine = input.nextLine();
                arraySplit1= inputLine.split("#");
                
                custNumber = Integer.parseInt(arraySplit1[0]);
                firstName = arraySplit1[1];
                surname = arraySplit1[2];
                phoneNumber = arraySplit1[3];
                creditStr = arraySplit1[4];                
                can = Boolean.parseBoolean(arraySplit1[5]);
                
                System.out.println(arraySplit1[0]+" "+arraySplit1[1]+" "+arraySplit1[2]+" "+arraySplit1[3]+" "+arraySplit1[4]+" "+arraySplit1[5]);
                
                credit = Double.parseDouble(creditStr);
                
                customerObj = new Customer(custNumber, firstName, surname, phoneNumber, credit, can);
                outFile.writeObject(customerObj);
              
            }
            catch(InputMismatchException ime)
            {
                System.out.print("ERROR...");
            }
            catch(IOException ioe){
                System.out.println("Err writing to file");
            }
             
        }
        
    }

     public void closeFiles()
    {
        try{
            input.close();  
            outFile.close();
         //   dvdOutFile.close();
        }
        catch(IOException ioe){
            System.out.println("Err closing file");
        }
        
    }
     public void openDvdFile(){
    
        try {
            input = new Scanner(new File("D:\\Users\\Liyabona Saki\\Downloads\\Project2\\MovieRentalServer\\Movies.txt"));    
            outFile  = new ObjectOutputStream(new FileOutputStream("D:\\Users\\Liyabona Saki\\Downloads\\Project2\\MovieRentalServer\\Movies.ser"));
       
           
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ServerApp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ServerApp.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
  
 public void readAndWriteRental() throws IOException
    {
        String[] arraySplit1 = new String[6];
        while(input.hasNext())
        {
            try
            {
                inputLine = input.nextLine();
                arraySplit1= inputLine.split("#");
                
                rentalNumber = Integer.parseInt(arraySplit1[0]);
                dateRented = arraySplit1[1];
                dateReturned = arraySplit1[2];
                PENALTY_COST_PER_DAY = Double.parseDouble(arraySplit1[3]);
                totalPenaltyCost = Double.parseDouble(arraySplit1[4]);                
                custNumber = Integer.parseInt(arraySplit1[5]);
                dvdNumber = Integer.parseInt(arraySplit1[6]);
                numDaysOverdue = Integer.parseInt(arraySplit1[7]);
              //  System.out.println(arraySplit1[0]+" "+arraySplit1[1]+" "+arraySplit1[2]+" "+arraySplit1[3]+" "+arraySplit1[4]+" "+arraySplit1[5]);
                //credit = Double.parseDouble(creditStr);
                rent = new Rental(rentalNumber, dateRented, dateReturned, PENALTY_COST_PER_DAY, totalPenaltyCost, custNumber, dvdNumber);
                outFile.writeObject(rent);
                
            //     System.out.println(rentalNumber + " " + dateRented + " " + dateReturned + " " + PENALTY_COST_PER_DAY+ " " + totalPenaltyCost+ " " + custNumber+ " " + dvdNumber+ " " + numDaysOverdue);
                System.out.println(rent.toString());
          
            }
            catch(InputMismatchException ime)
            {
                System.out.print("ERROR...");
            }
            catch(NumberFormatException nfe){
                System.out.println(nfe);
            }
             
        }
        
    }
    
    public void readAndWriteDvd(){
        String[] arraySplit1 = new String[4];
        while(input.hasNext())
        {
            try
            {
                inputLine = input.nextLine();
                arraySplit1= inputLine.split("#");
                dvdNumber = Integer.parseInt(arraySplit1[0]);
                title = arraySplit1[1];
                categoryStr = arraySplit1[2];
                releaseStr = arraySplit1[3];
                availableStr = arraySplit1[4];
                System.out.println(arraySplit1[0]+" "+arraySplit1[1]+" "+arraySplit1[2]+" "+arraySplit1[3]+" "+arraySplit1[4]); 
                release = Boolean.parseBoolean(releaseStr);
                available = Boolean.parseBoolean(availableStr);
                category = Integer.parseInt(categoryStr);
                DvdObj = new DVD(dvdNumber, title, category, release, available);
                outFile.writeObject(DvdObj);    
                
                
            }
            catch(InputMismatchException ime)
            {
                System.out.print("ERROR...");
            }
            catch(IOException ioe){
                System.out.println("Err writing to file");
            }
             
        }
        
    }
    
    public void closeDvd(){
      
        try{
            input.close();  
            outFile.close();
      //      br.close();
        }
        catch(IOException ioe){
            System.out.println("Err closing file");
        }
        
    }
    
  
     
     public void openSerFiles(){
     
        try {
            fis = new FileInputStream("D:\\Users\\Liyabona Saki\\Downloads\\Project2\\MovieRentalServer\\Customers.ser");
            inFile = new ObjectInputStream(fis);   
            
            mFis = new FileInputStream("D:\\Users\\Liyabona Saki\\Downloads\\Project2\\MovieRentalServer\\Movies.ser");
            mInFile = new ObjectInputStream(mFis);
            
            rFis = new FileInputStream("D:\\Users\\Liyabona Saki\\Downloads\\Project2\\MovieRentalServer\\Rental.ser");
            rInFile = new ObjectInputStream(rFis);
            
            System.out.println("Files read");
            
        } catch (FileNotFoundException ex) {
            System.out.println("File Not found");
        } catch (IOException ex) {
            System.out.println("Something went wrong");
        }
         
     }
     
        public void processRentalsSerFile(){
         
        try{ 
        int counter = 0;
        String rows = "";
         try{ 
             
             while(true){
                rent = (Rental) rInFile.readObject();  
                prepStat = conn.prepareStatement("INSERT INTO Rentals (Rental_No, DateRented, DateReturned, "
                        + "Cust_No, DVD_No, PenaltyCostPerDay) VALUES (?,?,?,?,?,?)");
            
           
                prepStat.setInt(1, rent.getRentalNumber());
                prepStat.setString(2, rent.getDateRented());
                prepStat.setString(3, rent.getDateReturned());
                prepStat.setInt(4, rent.getCustNumber()); 
                prepStat.setInt(5, rent.getDvdNumber());
                prepStat.setDouble(6, rent.getTotalPenaltyCost());
               
                prepStat.executeUpdate();
                counter ++;
             }
         
         } catch (EOFException eof){
            try {
                rows = rows + counter + " Rows of Rentals data added";
                out.writeObject(rows);
            } catch (IOException ex) {
                Logger.getLogger(ServerApp.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
         catch(IOException ex){
             
         } catch (ClassNotFoundException ex) {
             System.out.println("Class not found");
        }
         }catch (SQLException ex) {
             System.out.println("SQL ERROR....");
        }
        
     }
     
     
     
     public void processDvdSerFiles(){
        
    try{ 
        int counter = 0;
        String rows = "";
         try{ 
             
             while(true){
                DvdObj = (DVD) mInFile.readObject();
                
                prepStat = conn.prepareStatement("INSERT INTO DVDs (DVD_No, DVD_title, DVD_Category, "
                        + "New_Release, Available, DVD_PRICE) VALUES (?,?,?,?,?,?)");
                
                prepStat.setInt(1, DvdObj.getDvdNumber());
                prepStat.setString(2, DvdObj.getTitle());
                prepStat.setString(3, DvdObj.getCategory());
                prepStat.setBoolean(4, DvdObj.isNewRelease()); 
                prepStat.setBoolean(5, DvdObj.isAvailable());
                prepStat.setDouble(6, DvdObj.getPrice());
               
                prepStat.executeUpdate();
                counter ++;
             }
         
         } catch (EOFException eof){
            try {
                rows = rows + counter + " Rows of DVD data added";
                out.writeObject(rows);
            } catch (IOException ex) {
                Logger.getLogger(ServerApp.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
         catch(IOException ex){
             
         } catch (ClassNotFoundException ex) {
             System.out.println("Class not found");
        }
         }catch (SQLException ex) {
             System.out.println("SQL ERROR....");
        }
        
     }
     
     
     
     
     public void processCustSerFiles(){
        
        try{ 
        int counter = 0;
        String rows = ""; 
         
         try{
             
             while (true){
                customerObj = (Customer) inFile.readObject();
                
                        
                prepStat = conn.prepareStatement("INSERT INTO Customers (Cust_No, Cust_Name, Cust_Surname, "
                        + "Cust_Phone, Cust_Credit, CanRent) VALUES (?,?,?,?,?,?)");
                
                prepStat.setInt(1, customerObj.getCustNumber());
                prepStat.setString(2, customerObj.getName());
                prepStat.setString(3, customerObj.getSurname());
                prepStat.setString(4, customerObj.getPhoneNum());
                prepStat.setDouble(5, customerObj.getCredit());
                prepStat.setBoolean(6, customerObj.canRent()); 
                
                
               prepStat.executeUpdate();
               counter ++;
             }
            
         }catch(EOFException eof){
            try {
                rows = rows + counter + " Rows of Customer data added";
                out.writeObject(rows);
            } catch (IOException ex) {
                Logger.getLogger(ServerApp.class.getName()).log(Level.SEVERE, null, ex);
            }
         } catch (IOException ex) {
             System.out.println("Err.. Something went Wrong");
        } catch (ClassNotFoundException ex) {
             System.out.println("Class not found");
        }
        }catch (SQLException ex) {
             System.out.println("Cannot Load Data into tables. Either the tables are already loaded or Data is corrupt");
        }
     }
     
     public void updateCustomer(){
         
         int custNumber;
         String fName, lName, phone;
         double credAmt;
         boolean can;
         
  
         fName = customerObj.getName();
  
        try {   
        
           prepStat.setString(1, fName); 
      
            
        } catch (SQLException ex) {
            Logger.getLogger(ServerApp.class.getName()).log(Level.SEVERE, null, ex);
        }
                 
     }
     ///////////////////////////
      public ArrayList<DVD> insertMoview() throws SQLException, NullPointerException, ClassNotFoundException{

       
  
       ArrayList<DVD> movie = new ArrayList<DVD>();
        rs = stmt.executeQuery("SELECT * FROM DVD");
        
       int movieId, ctgy;
       String ttl;
       boolean avl, yRel;
       
       
       try{
         
       if (rs != null){     
        while (rs.next()) 
            {
            movieId = rs.getInt(1);
            ttl = rs.getString(2);
            ctgy = rs.getInt(3);
            yRel = rs.getBoolean(4);
            avl = rs.getBoolean(5);
            
            
           
       DvdObj = new DVD(movieId, ttl, ctgy, yRel, avl);    
       movie.add(DvdObj);
          
          


        }
                 }
       
        
       }
       catch(Exception e){
           e.printStackTrace();
       }
       return movie;
   }
      
     
     public ArrayList<Customer> insertCustomer() throws SQLException, NullPointerException, ClassNotFoundException{

       
        //st.executeUpdate(insertCustomer);
       ArrayList<Customer> customer = new ArrayList<Customer>();
        rs = stmt.executeQuery("SELECT * FROM CUSTOMER");
        
       
       try{
         
       if (rs != null){     
        while (rs.next()) 
            {
            custNumber = rs.getInt(1);
            firstName = rs.getString(2);
            surname = rs.getString(3);
            phoneNumber = rs.getString(4);
            credit = rs.getDouble(5);
            can = rs.getBoolean(6);
            
       //    System.out.println(custNum + " "+name +" "+ surname + " "+ phoneNumber + " "+ credit + " "+avail);
           
           customerObj = new Customer(custNumber, firstName,  surname, phoneNumber, credit, can);
           customer.add(customerObj);
           //


        }
                 }
       
        
       }
       catch(Exception e){
           e.printStackTrace();
       }
       return customer;
   }
     
     public void updCust(){
        try {
            try {
                Class.forName("org.apache.derby.jdbc.ClientDriver");
            } catch (ClassNotFoundException ex) {
                ex.getStackTrace();
            }
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/ADPFinalProject", "root","root");
            stmt = conn.createStatement();
            
            pStat = conn.prepareStatement("Update Customers SET Cust_Name = ?, Cust_Surname = ?, Cust_Phone = ?, Cust_Credit = ?, Can_Rent = ? WHERE Cust_No = ?");
        
                    pStat.setString(1, firstName);
                    pStat.setString(2, surname);
                    pStat.setString(3, phoneNumber);
                    pStat.setDouble(4, credit);
                    pStat.setBoolean(5, can);
                    pStat.setInt(6, custNumber);
                    
                    pStat.executeUpdate();
                    pStat.close();
        
        } catch (SQLException ex) {
            Logger.getLogger(ServerApp.class.getName()).log(Level.SEVERE, null, ex);
        }
                 
     } 

   public void showCustomer() {
        try {
            list = insertCustomer();
            
            for(int i=0; i< list.size(); i++){
                
                System.out.println(list.get(i).toString());
                
            }  } catch (SQLException ex) {
            Logger.getLogger(ServerApp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NullPointerException ex) {
            Logger.getLogger(ServerApp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ServerApp.class.getName()).log(Level.SEVERE, null, ex);
        }
   }
   
   public void deleteCustomer(){
       
   }
  
     public void closeSerFiles(){
        try {
            inFile.close();
            mInFile.close();
            rInFile.close();
            
        } catch (IOException ex) {
            System.out.println("Cannot close File");
        }
     }
     
    public void closeConnection(){
        
        try {
            out.close();
            in.close();
            client.close();
            listener.close();
            
        } catch (IOException ex) {
            ex.getStackTrace();
        }
        
    }
    
}
