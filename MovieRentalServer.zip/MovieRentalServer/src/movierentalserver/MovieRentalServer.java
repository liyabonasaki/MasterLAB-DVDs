package movierentalserver;

/**
 *
 * @author Liyabona Saki & Emihle Menzo
 */
public class MovieRentalServer {

   
    public static void main(String[] args) {
        ServerApp server = new ServerApp();
        
        server.listen();
        server.processClient();
        server.closeConnection();
    }
    
}
