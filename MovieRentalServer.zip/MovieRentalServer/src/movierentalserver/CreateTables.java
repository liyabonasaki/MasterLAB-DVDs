package movierentalserver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Liyabona Saki & Emihle Menzo
 */
class CreateTables {
    
    private static void CreateCustomer(){
        Connection con = null;
        Statement stmt = null;
        try{
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/FinalAssignmentDB","root","root");
             stmt = con.createStatement();
             
             //Query1
             String query1 = "CREATE TABLE Customer("
                           + "Cust_no INT NOT NULL ,"
                           + "Cust_Name VARCHAR(255),"
                           + "Cust_Surname VARCHAR(255),"
                           + "Cust_Phone VARCHAR(255), "
                           + "Cust_Credit DOUBLE NOT NULL,,"
                           + "canRent VARCHAR(255), "
                           + "PRIMARY KEY (Cust_No))";
             
//             stmt.execute(query1);
             stmt.executeUpdate(query1);
             
             //Query2
              String query2 = "CREATE TABLE DVD("
                           + "DVD_No INT NOT NULL ,"
                           + "DVD_title VARCHAR(255), Price DOUBLE NOT NULL, "
                           + "DVD_Category VARCHAR(255), "
                           + "New_Release VARCHAR(255), "
                           + "Available VARCHAR(255), "
                           + "PRIMARY KEY (DVD_No))";
             
             stmt.executeUpdate(query2);
             
             //Query3
              String query3 = "CREATE TABLE Rental("
                           + "Rental_No INT NOT NULL ,"
                           + "DateRented VARCHAR(255),"
                           + "DateReturned VARCHAR(255), "
                           + "Cust_No INT NOT NULL,"
                           + "DVD_No INT NOT NULL,"
                           + "totalPenaltyCost DOUBLE,"
                           + "PenaltyCostPerDay DOUBLE NOT NULL,"
                           + "PRIMARY KEY (Rental_No))";
             
             stmt.executeUpdate(query3);
             JOptionPane.showMessageDialog(null, "Tables Succesfully created");
        }catch(Exception e){
            e.getStackTrace();
            
        }finally{
            try{
                con.close();
                stmt.close();
            }catch(Exception e){
                e.getStackTrace();
            }
            
        }
        
    }
    
    protected void Create(){
        CreateCustomer();
    }
    
}
