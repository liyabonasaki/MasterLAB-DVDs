
package movierentalserver;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Liyabona Saki & Emihle Menzo
 */
public class InertRentalData {
    
    Connection conn = null;
     private FileInputStream fis, mFis, rFis;
    private ObjectInputStream inFile, mInFile, rInFile;
     //For DVD Class
   private int dvdNumber, category;
    private String title, categoryStr, releaseStr, availableStr;
    private boolean release, available;
    
    DVD DvdObj;
    
    
    //For Customer Class 
    private double credit;
    private int custNumber;
    private String firstName, surname, phoneNumber, creditStr;
    boolean can;
    
  
    
    
    //////////////
    private int rentalNumber;
    private String dateRented;
    private String dateReturned;
    private double totalPenaltyCost;
    private double PENALTY_COST_PER_DAY;
    private int numDaysOverdue;
    Rental rent;
    
     private Scanner input;
     private String inputLine;
    private ObjectOutputStream outFile;
    
     public void openRentalFiles() throws IOException
    {
        try
        {
            input = new Scanner(new File("D:\\Users\\Liyabona Saki\\Downloads\\Project2\\MovieRentalServer\\Rentals.txt"));
            outFile = new ObjectOutputStream(new FileOutputStream("D:\\Users\\Liyabona Saki\\Downloads\\Project2\\MovieRentalServer\\Rental.ser"));
        }
        catch(FileNotFoundException fnf)
        {
            System.out.println("File not found...");
            System.exit(1);
        }
        
        
    }
    
     public void readAndWriteRental() throws IOException {
         
        String[] arraySplit1 = new String[6];
        while(input.hasNext())
        {
            try
            {
                inputLine = input.nextLine();
                arraySplit1= inputLine.split("#");
                
                rentalNumber = Integer.parseInt(arraySplit1[0]);
                dateRented = arraySplit1[1];
                dateReturned = arraySplit1[2];
                PENALTY_COST_PER_DAY = Double.parseDouble(arraySplit1[3]);
                totalPenaltyCost = Double.parseDouble(arraySplit1[4]);                
                custNumber = Integer.parseInt(arraySplit1[5]);
                dvdNumber = Integer.parseInt(arraySplit1[6]);
                numDaysOverdue = Integer.parseInt(arraySplit1[7]);
              
//                rent = new Rental(rentalNumber, dateRented, dateReturned, custNumber, dvdNumber);
                outFile.writeObject(rent);
                
          
                System.out.println(rent.toString());
            
            }
            catch(InputMismatchException ime)
            {
                System.out.print("ERROR...");
            }
            catch(NumberFormatException nfe){
                System.out.println(nfe);
            }
             
        }
        
    }
     
   public void openSerFiles(){
     
        try {
            
            
            FileInputStream rFis = new FileInputStream("D:\\Users\\Liyabona Saki\\Downloads\\Project2\\MovieRentalServer\\Rental.ser");
            ObjectInputStream rInFile = new ObjectInputStream(rFis);
            
            System.out.println("Files read");
            
        } catch (FileNotFoundException ex) {
            System.out.println("File Not found");
        } catch (IOException ex) {
            System.out.println("Something went wrong");
        }
        
     }
      
       
       PreparedStatement prepStat, pStat;
      public void processRentalsSerFile() throws SQLException{
         
        try {      
            while(true){
      
            rent = (Rental) rInFile.readObject();  
            prepStat = conn.prepareStatement("INSERT INTO Rentals (Rental_No, DateRented, DateReturned, "
                        + "Cust_No, DVD_No,PenaltyCostPerDay) VALUES (?,?,?,?,?,?)");
            
            //Rental_No, DateRented, DateReturned, Cust_No, DVD_No, PenaltyCost
           
                prepStat.setInt(1, rent.getRentalNumber());
                prepStat.setString(2, rent.getDateRented());
                prepStat.setString(3, rent.getDateReturned());
                prepStat.setInt(4, rent.getCustNumber()); 
                prepStat.setInt(5, rent.getDvdNumber());
                prepStat.setDouble(6, rent.getTotalPenaltyCost());

                prepStat.executeUpdate();
            }
            
        } catch (IOException ex) {
            
        } catch (ClassNotFoundException ex) {
          
        } 
        catch (SQLException ex) {
          
        }
        
     }
   
  
}


